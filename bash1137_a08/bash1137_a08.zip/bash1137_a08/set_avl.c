/*
--------------------------------------------------
Project: a8q2
File:    set_avl.c
Author:  Manahil Bashir
Version: 2025-11-05
--------------------------------------------------
*/
#include "string.h" 
#include "avl.h"
#include "set_avl.h"

int set_size(SET *s) {
    return (s == NULL) ? 0 : s->size;
}

int set_contain(SET *s, char *e){
  if (s == NULL || s->root == NULL) return 0;
  AVLNODE *node = avl_search(s->root, e);
  return (node != NULL) ? 1 : 0;
}

void set_add(SET *s, char *e)
{
    if (s == NULL) return;
  
   if (set_contain(s, e))
    return;

  RECORD rec;
  strcpy(rec.name, e);
  rec.score = 0;   
  
  avl_insert(&s->root, rec);
  s->size++;
}

void set_remove(SET *s, char *e)
{
    if (s == NULL) return;
  
    if (!set_contain(s, e))
    return;

  avl_delete(&s->root, e);
  s->size--;  
}

void set_clean(SET *s){
  if (s == NULL) return;
  avl_clean(&s->root);
  s->root = NULL;
  s->size = 0;
}   